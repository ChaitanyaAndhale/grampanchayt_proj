const Hero = () => {
  return (
    <section id="home" className="relative overflow-hidden">
      {/* Background with gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/90 via-secondary/90 to-accent/90 z-0" />
      
      <div className="relative z-10 container mx-auto px-4 py-20 md:py-32">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 animate-fade-in">
            Welcome to Golegaon
          </h2>
          <p className="text-lg md:text-xl lg:text-2xl mb-8 leading-relaxed animate-fade-in opacity-90">
            A vibrant village community rooted in tradition, growing with progress. 
            Experience the warmth of rural Maharashtra where heritage meets development.
          </p>
          <div className="flex flex-wrap justify-center gap-4 animate-fade-in">
            <div className="gov-badge bg-white/20 backdrop-blur-sm border border-white/30">
              <span className="text-white">🏛️ Established Community</span>
            </div>
            <div className="gov-badge bg-white/20 backdrop-blur-sm border border-white/30">
              <span className="text-white">🌾 Agricultural Heritage</span>
            </div>
            <div className="gov-badge bg-white/20 backdrop-blur-sm border border-white/30">
              <span className="text-white">🤝 Unity in Diversity</span>
            </div>
          </div>
        </div>
      </div>

      {/* Decorative wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 120" className="w-full h-16 fill-background">
          <path d="M0,64L48,69.3C96,75,192,85,288,80C384,75,480,53,576,48C672,43,768,53,864,58.7C960,64,1056,64,1152,58.7C1248,53,1344,43,1392,37.3L1440,32L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z"></path>
        </svg>
      </div>
    </section>
  );
};

export default Hero;
