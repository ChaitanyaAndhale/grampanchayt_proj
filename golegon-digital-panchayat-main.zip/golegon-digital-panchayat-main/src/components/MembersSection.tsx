import { Card, CardContent } from "@/components/ui/card";
import { Phone, Mail } from "lucide-react";

interface Member {
  name: string;
  designation: string;
  contact: string;
  email: string;
  role: "sarpanch" | "upsarpanch" | "member";
}

const MembersSection = () => {
  const members: Member[] = [
    {
      name: "Mukta Sanjay Andhale",
      designation: "Sarpanch",
      contact: "+91 98765 43210",
      email: "sarpanch.golegaon@gov.in",
      role: "sarpanch",
    },
    {
      name: "Ramesh Kumar Patil",
      designation: "Upsarpanch",
      contact: "+91 98765 43211",
      email: "upsarpanch.golegaon@gov.in",
      role: "upsarpanch",
    },
    {
      name: "Sunita Devi Sharma",
      designation: "Panchayat Member",
      contact: "+91 98765 43212",
      email: "member1.golegaon@gov.in",
      role: "member",
    },
    {
      name: "Vijay Baburao Deshmukh",
      designation: "Panchayat Member",
      contact: "+91 98765 43213",
      email: "member2.golegaon@gov.in",
      role: "member",
    },
    {
      name: "Anita Rajesh Kadam",
      designation: "Panchayat Member",
      contact: "+91 98765 43214",
      email: "member3.golegaon@gov.in",
      role: "member",
    },
    {
      name: "Prakash Ganesh Bhosale",
      designation: "Panchayat Member",
      contact: "+91 98765 43215",
      email: "member4.golegaon@gov.in",
      role: "member",
    },
  ];

  const getRoleColor = (role: string) => {
    switch (role) {
      case "sarpanch":
        return "bg-primary text-white";
      case "upsarpanch":
        return "bg-secondary text-white";
      default:
        return "bg-accent text-white";
    }
  };

  return (
    <section id="members" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <h2 className="section-title">Current Gram Panchayat Members</h2>
        
        <p className="text-lg text-muted-foreground mb-12 max-w-3xl">
          Meet our dedicated Gram Panchayat representatives working together for the 
          development and welfare of Golegaon village.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {members.map((member, index) => (
            <Card
              key={index}
              className="gov-card group hover:scale-105 transition-all duration-300"
            >
              <CardContent className="p-6">
                {/* Member Photo Placeholder */}
                <div className="relative mb-4">
                  <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg">
                    <span className="text-4xl text-white">
                      {member.name.charAt(0)}
                    </span>
                  </div>
                  <div
                    className={`absolute bottom-0 right-1/2 translate-x-1/2 translate-y-2 gov-badge ${getRoleColor(
                      member.role
                    )} shadow-md`}
                  >
                    {member.role === "sarpanch" ? "सरपंच" : member.role === "upsarpanch" ? "उपसरपंच" : "सदस्य"}
                  </div>
                </div>

                <div className="text-center space-y-3 pt-4">
                  <h3 className="text-xl font-bold text-accent">{member.name}</h3>
                  <p className="text-muted-foreground font-medium">{member.designation}</p>

                  <div className="pt-4 space-y-2 text-sm">
                    <div className="flex items-center justify-center gap-2 text-muted-foreground hover:text-primary transition-colors">
                      <Phone className="w-4 h-4" />
                      <span>{member.contact}</span>
                    </div>
                    <div className="flex items-center justify-center gap-2 text-muted-foreground hover:text-primary transition-colors break-all">
                      <Mail className="w-4 h-4" />
                      <span className="text-xs">{member.email}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default MembersSection;
