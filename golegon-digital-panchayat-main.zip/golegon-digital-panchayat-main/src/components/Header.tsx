import { useState } from "react";
import { Globe } from "lucide-react";
import { Button } from "@/components/ui/button";

const Header = () => {
  const [language, setLanguage] = useState<"en" | "mr">("en");

  const toggleLanguage = () => {
    setLanguage(language === "en" ? "mr" : "en");
  };

  return (
    <header className="bg-card border-b-4 border-primary shadow-md">
      {/* Top Bar */}
      <div className="bg-gradient-to-r from-primary via-secondary to-accent py-1">
        <div className="container mx-auto" />
      </div>

      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          {/* Logo Section */}
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg">
              <span className="text-2xl md:text-3xl font-bold text-white">GP</span>
            </div>
            <div>
              <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-accent leading-tight">
                {language === "en" ? "Gram Panchayat Golegaon" : "ग्राम पंचायत गोलेगाव"}
              </h1>
              <p className="text-sm md:text-base text-muted-foreground">
                {language === "en" 
                  ? "Sarpanch: Mukta Sanjay Andhale" 
                  : "सरपंच: मुक्ता संजय आंधळे"}
              </p>
            </div>
          </div>

          {/* Language Toggle */}
          <Button
            onClick={toggleLanguage}
            variant="outline"
            size="sm"
            className="gap-2 hover:bg-primary hover:text-white transition-colors"
          >
            <Globe className="w-4 h-4" />
            <span className="hidden sm:inline">{language === "en" ? "मराठी" : "English"}</span>
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
