import { Card, CardContent } from "@/components/ui/card";
import villageTemple from "@/assets/village-temple.jpg";
import villageFields from "@/assets/village-fields.jpg";
import villageSchool from "@/assets/village-school.jpg";
import communityHall from "@/assets/community-hall.jpg";
import villageRoads from "@/assets/village-roads.jpg";
import waterResources from "@/assets/water-resources.jpg";
import villageSquare from "@/assets/village-square.jpg";
import localMarket from "@/assets/local-market.jpg";

const VillageSection = () => {
  const villageImages = [
    { id: 1, caption: "Village Temple", src: villageTemple },
    { id: 2, caption: "Agricultural Fields", src: villageFields },
    { id: 3, caption: "Village School", src: villageSchool },
    { id: 4, caption: "Community Hall", src: communityHall },
    { id: 5, caption: "Village Roads", src: villageRoads },
    { id: 6, caption: "Water Resources", src: waterResources },
    { id: 7, caption: "Village Square", src: villageSquare },
    { id: 8, caption: "Local Market", src: localMarket },
  ];

  return (
    <section id="village" className="py-16 md:py-24 bg-background">
      <div className="container mx-auto px-4">
        <h2 className="section-title">About Our Village – Golegaon</h2>
        
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <Card className="gov-card">
            <CardContent className="p-6">
              <h3 className="text-2xl font-bold text-accent mb-4">Our Heritage</h3>
              <p className="text-muted-foreground leading-relaxed">
                Golegaon is a thriving village community located in the heart of Maharashtra. 
                Our village has a rich cultural heritage dating back generations, where traditional 
                values blend seamlessly with modern progress. The community is known for its 
                agricultural excellence, producing high-quality crops that contribute to the region's prosperity.
              </p>
            </CardContent>
          </Card>

          <Card className="gov-card">
            <CardContent className="p-6">
              <h3 className="text-2xl font-bold text-accent mb-4">Community Life</h3>
              <p className="text-muted-foreground leading-relaxed">
                Our village prides itself on strong community bonds and collective growth. With dedicated 
                educational institutions, healthcare facilities, and infrastructure development, Golegaon 
                continues to evolve while preserving its cultural identity. The Gram Panchayat, under the 
                leadership of Sarpanch Mukta Sanjay Andhale, works tirelessly for the welfare of all residents.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Village Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          <Card className="gov-card text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-2">500+</div>
              <div className="text-sm text-muted-foreground">Families</div>
            </CardContent>
          </Card>
          <Card className="gov-card text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-secondary mb-2">1200+</div>
              <div className="text-sm text-muted-foreground">Population</div>
            </CardContent>
          </Card>
          <Card className="gov-card text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-accent mb-2">850</div>
              <div className="text-sm text-muted-foreground">Acres of Land</div>
            </CardContent>
          </Card>
          <Card className="gov-card text-center">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-primary mb-2">3</div>
              <div className="text-sm text-muted-foreground">Schools</div>
            </CardContent>
          </Card>
        </div>

        {/* Village Gallery */}
        <div id="gallery">
          <h3 className="text-2xl font-bold text-accent mb-6">Village Gallery</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {villageImages.map((image) => (
              <div key={image.id} className="image-hover group">
                <div className="relative aspect-square bg-muted rounded-lg overflow-hidden">
                  <img 
                    src={image.src} 
                    alt={image.caption}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <p className="text-white font-medium text-sm">{image.caption}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default VillageSection;
