import { Heart } from "lucide-react";

const Footer = () => {
  return (
    <footer id="contact" className="bg-accent text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* About */}
          <div>
            <h3 className="text-xl font-bold mb-4">Gram Panchayat Golegaon</h3>
            <p className="text-white/80 leading-relaxed">
              Working together for the development and prosperity of our village. 
              Committed to transparent governance and community welfare.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-white/80">
              <li><a href="#home" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#village" className="hover:text-white transition-colors">About Village</a></li>
              <li><a href="#gram-sabha" className="hover:text-white transition-colors">Gram Sabha</a></li>
              <li><a href="#members" className="hover:text-white transition-colors">Members</a></li>
              <li><a href="#gallery" className="hover:text-white transition-colors">Gallery</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xl font-bold mb-4">Contact Information</h3>
            <div className="space-y-2 text-white/80">
              <p>Gram Panchayat Office</p>
              <p>Golegaon Village</p>
              <p>Maharashtra, India</p>
              <p className="mt-4">📞 +91 98765 43210</p>
              <p>✉️ office.golegaon@gov.in</p>
            </div>
          </div>
        </div>

        <div className="border-t border-white/20 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-white/80 text-sm">
              © 2024 Golegaon Gram Panchayat. All rights reserved.
            </p>
            <p className="text-white/80 text-sm flex items-center gap-2">
              Developed with <Heart className="w-4 h-4 text-red-400 fill-red-400" /> by Chaitanya
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
